package com.praveen.audit.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.praveen.audit.model.AuditMessage;
import com.praveen.audit.model.MessageRequest;
import com.praveen.audit.producer.MessageProducer;
import com.praveen.audit.repository.AuditMessageRepository;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@Tag(description = "Message Operations", name = "Message Operations")
public class MessageController {

	private MessageProducer messageProducer;

	private AuditMessageRepository auditMessageRepository;

	public MessageController(MessageProducer messageProducer, AuditMessageRepository auditMessageRepository) {
		this.messageProducer = messageProducer;
		this.auditMessageRepository = auditMessageRepository;
	}

	@PostMapping("/messages")
	@Operation(description = "Post Message", tags = "Message Operations")
	public void produce(@RequestBody MessageRequest messageRequest) {
		messageProducer.sendMessage(messageRequest);

	}

	@GetMapping("/messages")
	@Operation(description = "Fetch Message", tags = "Message Operations")
	public List<AuditMessage> consume() {
		return auditMessageRepository.findAll();
	}

}
