package com.praveen.audit.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
public class MessageRequest implements Serializable{
	private static final long serialVersionUID = -8802901894109079082L;
	private String appName;
	private String message;

}
