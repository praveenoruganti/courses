package com.praveen.audit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.praveen.audit.config.ApplicationConfig;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;

@SpringBootApplication
public class AuditListener {
	public static void main(String[] args) {
		SpringApplication.run(AuditListener.class);
	}

	@Bean
	public OpenAPI customOpenAPI(ApplicationConfig applicationConfig) {

		return new OpenAPI().components(new Components()).info(new Info().title(applicationConfig.getOpenApiTitle())
				.description(applicationConfig.getOpenApiDescription())
				.contact(new Contact().name("Praveen Oruganti").email("praveenorugantitech@gmail.com")
						.url("https://praveenorugantitech.github.io"))
				.termsOfService("https://praveenorugantitech.github.io/#/aboutme")
				.license(new License().name("GNU General Public License v3.0").url("https://www.gnu.org/licenses")));
	}
}
