package com.praveen.audit.listener;

import static net.logstash.logback.argument.StructuredArguments.kv;

import java.sql.Date;
import java.time.LocalDate;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.praveen.audit.model.AuditMessage;
import com.praveen.audit.model.MessageRequest;
import com.praveen.audit.repository.AuditMessageRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class MessageListener {

	@Autowired
	private AuditMessageRepository auditMessageRepository;

	@RabbitListener(queues = "${app.rabbitmq.queueName}")
	public void receivedMessage(MessageRequest message) {
		log.info("Message Received", kv("MESSAGE", message));
		try {
			auditMessageRepository.save(AuditMessage.builder().appName(message.getAppName())
					.message(message.getMessage()).creationDate(Date.valueOf(LocalDate.now())).build());
			log.info("Message Pushed to DB", kv("MESSAGE", message));

		} catch (Exception e) {
			log.error("Message not Pushed to DB", kv("MESSAGE", message));
		}
	}

}
