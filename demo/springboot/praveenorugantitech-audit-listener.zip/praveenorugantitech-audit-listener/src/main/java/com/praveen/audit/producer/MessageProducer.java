package com.praveen.audit.producer;

import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import static net.logstash.logback.argument.StructuredArguments.kv;

import com.praveen.audit.model.MessageRequest;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class MessageProducer {

	@Autowired
	private AmqpTemplate amqpTemplate;

	@Value("${app.rabbitmq.queueName}")
	private String queueName;

	@Value("${app.rabbitmq.topicExchange}")
	private String topicExchange;

	public void sendMessage(MessageRequest message) {
		amqpTemplate.convertAndSend(topicExchange, queueName, message);
		log.info("Message Sent", kv("MESSAGE", message));

	}
}
