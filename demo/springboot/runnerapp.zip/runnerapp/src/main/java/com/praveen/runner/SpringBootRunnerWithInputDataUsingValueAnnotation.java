package com.praveen.runner;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import lombok.Data;
import lombok.ToString;

@Component
@Data
@ToString
public class SpringBootRunnerWithInputDataUsingValueAnnotation implements CommandLineRunner {
	@Value("${system.product.id}")
	private int prodId;

	@Value("${system.product.name}")
	private String prodName;

	@Value("${system.product.description}")
	private String prodDesc;

	@Value("${system.product.code}")
	private String prodCode;

	public void run(String... args) throws Exception {
		System.out.println("@Value Annotation\n" + this);
	}
}