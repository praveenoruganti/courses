package com.praveen.runner;

import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/*CommandLineRunner with Order Annotation*/
@Component
@Order(1)
public class SpringBootCommandLineRunner implements CommandLineRunner {
	@Override
	public void run(String... args) throws Exception {
		System.out.println("Hi CommandLine Runner");
	}

}