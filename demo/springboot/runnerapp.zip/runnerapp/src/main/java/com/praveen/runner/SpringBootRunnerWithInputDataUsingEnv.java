package com.praveen.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

@Component
public class SpringBootRunnerWithInputDataUsingEnv implements CommandLineRunner {

	@Autowired
	private Environment env;

	public void run(String... args) throws Exception {
		System.out.println("Using Environment");
		System.out.println(env.getProperty("system.product.id"));
		System.out.println(env.getProperty("system.product.name"));
		System.out.println(env.getProperty("system.product.description"));
		System.out.println(env.getProperty("system.product.code"));

	}
}