package com.praveen.runner;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;
import lombok.ToString;

@Component
@Data
@ToString
@ConfigurationProperties("system.product")

public class SpringBootRunnerWithInputDataUsingConfigurationProperties implements CommandLineRunner {
	private int id;

	private String name;

	private String description;

	private String code;

	public void run(String... args) throws Exception {
		System.out.println("@ConfigurationProperties Annotation\n" + this);
	}
}